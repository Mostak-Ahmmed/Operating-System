#!/bin/bash
read -p "Enter radius: " r

 Area= echo "scale = 2; $r*$r*3.1416"  |bc
 echo $Area

#Circle:
#!/bin/bash
read -p "Enter radius: " r

 Area= echo "scale = 2; $r*$r*3.1416"  |bc
 echo $Area