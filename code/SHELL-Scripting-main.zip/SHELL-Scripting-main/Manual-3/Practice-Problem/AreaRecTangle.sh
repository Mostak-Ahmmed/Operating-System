#Rectangle:
#!/bin/bash
read -p "Enter bread: " a
read -p "Enter height: " b

let mul=$a*$b
echo "Rectangle Area=$mul"