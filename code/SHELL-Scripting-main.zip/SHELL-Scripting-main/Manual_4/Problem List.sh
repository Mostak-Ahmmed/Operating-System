Normal Problem?
-------------------
1. Write a Shell program to find the sum of odd and even numbers from a set of numbers.
2. Write a Shell program to find the smallest number from a set of numbers.
3. Write a Shell program to find the sum of all numbers between 50 and 100, which are divisible by 3 and
not divisible by 5.
4. Write a Shell program to find the second highest number from a set of numbers.
5. Write a Shell program to find the factorial of a number using for loop.
6. Write a Shell program to generate Fibonacci series.

Problem is find the value from the numbers?
--------------------------------
7. Write a Shell program to find the smallest digit from a number.
8. Write a Shell program to find the second largest digit from a number.
9. Write a Shell program to find the sum of digits of a number.
10. Write a Shell program to check the given integer is Armstrong number or not.
11. Write a Shell program to find the sum of odd digits and even digits from a number.
12. Write a Shell program to find the largest digit of a number

Problem solved using Function?
-----------------------------------------
13. Write a Shell program to find the largest number between two numbers using function.
14. Write a Shell program to find the sum of the numbers passed as parameters.

Array Related Problem list?
------------------------------
15. Write a Shell program to find the sum of odd and even numbers.
16. Write a Shell program to find the average of n numbers.
17. Write a Shell Program to find the largest element of an array.
18. Write a Shell Program to find the smallest element of an array.
